
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp> 
struct SCoordinates {
    int x;
    int y;
};

enum SDirection {SUP = 0, SRIGHT = 1, SDOWN = 2, SLEFT = 3};

class Snake : public sf::Drawable, public sf::Transformable {
public:

    Snake();
    
    ~Snake();

    int get_len();

    void snake_init();

    void next_step();

    void turn(SDirection step);

    void Ai_turn();

    void add_len();

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;

private:
    SCoordinates * snake_arr;

    SCoordinates eat_coordinates;

    sf::Texture body_texture;

    sf::Texture box_texture;

    sf::Texture head_texture;

    sf::Texture eat_texture;

    sf::Font dejavu;

    int snake_len;

    int direct;

    bool can_turn;
    bool resized;

    bool game_over;
};


