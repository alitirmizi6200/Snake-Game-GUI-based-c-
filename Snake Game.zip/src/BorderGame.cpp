#include "BorderGame.hpp"
#include <SFML/Audio.hpp>
BorderGame::BorderGame() {///usr/share/snake/res/
    sf::Image mw_icon;
    if(!(mw_icon.loadFromFile("res/snake.png")) && !(mw_icon.loadFromFile("/usr/share/snake/res/snake.png")));

    main_win = new sf::RenderWindow(sf::VideoMode(540, 750), "Snake"); 
  

    if(!(dejavu.loadFromFile("res/DejaVuSansMono.ttf")) && !(dejavu.loadFromFile("/usr/share/snake/res/DejaVuSansMono.ttf"))) ;

    if(!(earth.loadFromFile("res/Black2.png")) && !(earth.loadFromFile("/usr/share/snake/res/Black2.png"))) ;

    if(!(H_boxes.loadFromFile("res/hbox.png")) && !(H_boxes.loadFromFile("/usr/share/snake/res/hbox.png")));

    if(!(V_boxes.loadFromFile("res/Vbox.png")) && !(V_boxes.loadFromFile("/usr/share/snake/res/Vbox.png")));

    if(!(background.loadFromFile("res/background.png")) && !(background.loadFromFile("/usr/share/snake/res/background.png")));

    if(!(life.loadFromFile("res/life.png")) && !(life.loadFromFile("/usr/share/snake/res/life.png")));

    mw_game.snake_init();
    mw_game.setPosition(sf::Vector2f(18, 18));

    speed = 0.3;

}
/*
int main()
{
    BorderGame snake;

    snake.BorderRun();

    return 0;
}*/
 BorderGame::~BorderGame() {
    delete  main_win;
}

void BorderGame::BorderRun() {
    frame_ptr.restart();

    while(main_win->isOpen()){
        if(main_win->pollEvent(mw_event)){
            if(mw_event.type == sf::Event::Closed) main_win->close();// to close program

            //if(mw_event.type == sf::Event::KeyPressed) {
                switch (mw_event.key.code) {
                    case sf::Keyboard::Escape : main_win->close(); break;
                    case sf::Keyboard::Up: mw_game.turn(UP); break;
                    case sf::Keyboard::Right: mw_game.turn(RIGHT); break;
                    case sf::Keyboard::Down: mw_game.turn(DOWN); break;
                    case sf::Keyboard::Left: mw_game.turn(LEFT); break;

                    case sf::Keyboard::F2: mw_game.snake_init();  break;

               

                    default: break;
                }
            //}
        }

        if(mw_game.get_len() == 3) speed = 0.2;
        if(mw_game.get_len() == 5) speed = 0.15;
        if(mw_game.get_len() == 8) speed = 0.1;
        if(mw_game.get_len() == 15) speed = 0.075;
        if(mw_game.get_len() == 21) speed = 0.06;
        if(mw_game.get_len() > 30) speed = 0.05;

        if(frame_ptr.getElapsedTime().asSeconds() > speed){
            frame_ptr.restart();
            mw_game.next_step();
        }

        main_win->clear();

        sf::Sprite back(background);
        back.setPosition(0, 0);
        main_win->draw(back);

        sf::Sprite earth_back;

        earth_back.setTexture(earth);
        earth_back.setScale(0.48828125, 0.48828125);
        earth_back.setPosition(20, 20);

        main_win->draw(earth_back);
        // HORIZONTAL BOXEX
        

        sf::Sprite box_back_u(H_boxes);
        box_back_u.setPosition(20, 20);
         main_win->draw(box_back_u);
         
        sf::Sprite box_back_d(H_boxes);
        box_back_d.setPosition(20, 500);
        main_win->draw(box_back_d);

        sf::Sprite box_back_l(V_boxes);
        box_back_l.setPosition(20, 20);
         main_win->draw(box_back_l);
         
        sf::Sprite box_back_r(V_boxes);
        box_back_r.setPosition(500, 20);
        main_win->draw(box_back_r);

        main_win->draw(mw_game);

        
        sf::Sprite lifei(life);

        if (mw_game.get_count() == 0){
           sf::Sprite lifei(life);
            lifei.setPosition(400, 550);
            main_win->draw(lifei);

            sf::Sprite lifej(life);
            lifej.setPosition(430, 550);
            main_win->draw(lifej);

            sf::Sprite lifek(life);
            lifek.setPosition(460, 550);
            main_win->draw(lifek);
        }

        else if(mw_game.get_count() == 1){
            sf::Sprite lifel(lifei);
            lifel.setPosition(400, 550);
            main_win->draw(lifel);

            sf::Sprite lifem(lifei);
            lifem.setPosition(430, 550);
            main_win->draw(lifem);

        }
        else if(mw_game.get_count() == 2){
            sf::Sprite lifen(lifei);
            lifen.setPosition(400, 550);
            main_win->draw(lifen);
        }

        sf::Text score("Score : " + std::to_string(mw_game.get_len()), dejavu, 30);
        score.setFillColor(sf::Color::White);
        score.setPosition(sf::Vector2f(175, 550));

        main_win->draw(score);

        score.setString("Instruction :");
        score.setCharacterSize(28);
        score.setPosition(sf::Vector2f(50, 600));

        main_win->draw(score);

        score.setString("* F2 - new game");
        score.setCharacterSize(14);
        score.setPosition(sf::Vector2f(60, 650));

        main_win->draw(score);

        score.setString("* ESC - exit game");
        score.setCharacterSize(14);
        score.setPosition(sf::Vector2f(60, 670));

        main_win->draw(score);

        score.setString("* Arrows - to turn");
        score.setCharacterSize(14);
        score.setPosition(sf::Vector2f(60, 690));

        main_win->draw(score);

        main_win->draw(score);

        main_win->display();
    }
}