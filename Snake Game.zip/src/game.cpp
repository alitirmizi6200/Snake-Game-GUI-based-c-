#include "game.hpp"
Game::Game() {///usr/share/snake/res/
    sf::Image mw_icon;
    if(!(mw_icon.loadFromFile("res/snake.png")) && !(mw_icon.loadFromFile("/usr/share/snake/res/snake.png")));

    main_win = new sf::RenderWindow(sf::VideoMode(540, 750), "Snake"); 
  

    if(!(dejavu.loadFromFile("res/DejaVuSansMono.ttf")) && !(dejavu.loadFromFile("/usr/share/snake/res/DejaVuSansMono.ttf"))) ;

    if(!(earth.loadFromFile("res/Black.png")) && !(earth.loadFromFile("/usr/share/snake/res/Black.png"))) ;

    if(!(background.loadFromFile("res/Black.png")) && !(background.loadFromFile("/usr/share/snake/res/Black.png")));

  

    mw_game.snake_init();
    mw_game.setPosition(sf::Vector2f(18, 18));

    speed = 0.3;

}

Game::~Game() {
    delete  main_win;
}
/*
int main()
{
   Game snake;

    snake.Run();

    return 0;
}*/

void Game::Run() {
    frame_ptr.restart();

    while(main_win->isOpen()){
        if(main_win->pollEvent(mw_event)){
            if(mw_event.type == sf::Event::Closed) main_win->close();// to close program

            //if(mw_event.type == sf::Event::KeyPressed) {
                switch (mw_event.key.code) {
                    case sf::Keyboard::Escape : main_win->close(); break;
                    case sf::Keyboard::Up: mw_game.turn(SUP); break;
                    case sf::Keyboard::Right: mw_game.turn(SRIGHT); break;
                    case sf::Keyboard::Down: mw_game.turn(SDOWN); break;
                    case sf::Keyboard::Left: mw_game.turn(SLEFT); break;

                    case sf::Keyboard::F2: mw_game.snake_init();  break;

               

                    default: break;
                }
            //}
        }

        if(mw_game.get_len() == 3) speed = 0.2;
        if(mw_game.get_len() == 5) speed = 0.15;
        if(mw_game.get_len() == 8) speed = 0.1;
        if(mw_game.get_len() == 15) speed = 0.075;
        if(mw_game.get_len() == 21) speed = 0.06;
        if(mw_game.get_len() > 30) speed = 0.05;

        if(frame_ptr.getElapsedTime().asSeconds() > speed){
            frame_ptr.restart();
            mw_game.next_step();
        }

        main_win->clear();

        sf::Sprite back(background);
        back.setPosition(0, 0);

        main_win->draw(back);

        sf::Sprite earth_back;

        earth_back.setTexture(earth);
        earth_back.setScale(0.48828125, 0.48828125);
        earth_back.setPosition(20, 20);

        main_win->draw(earth_back);

        sf::RectangleShape line;
        line.setSize(sf::Vector2f(500, 0));
        // line.setFillColor(sf::Color(0, 0, 0));

        for(int i{1}; i < 25; i++){
            line.setPosition(20, 20 + 20 * i);
            main_win->draw(line);
        }

        line.setSize(sf::Vector2f(0, 500));

      

        main_win->draw(mw_game);

        sf::Text score("Score : " + std::to_string(mw_game.get_len()), dejavu, 30);
        score.setFillColor(sf::Color::White);
        score.setPosition(sf::Vector2f(175, 550));

        main_win->draw(score);

        score.setString("Instruction :");
        score.setCharacterSize(28);
        score.setPosition(sf::Vector2f(50, 600));

        main_win->draw(score);

        score.setString("* F2 - new game");
        score.setCharacterSize(14);
        score.setPosition(sf::Vector2f(60, 650));

        main_win->draw(score);

        score.setString("* ESC - exit game");
        score.setCharacterSize(14);
        score.setPosition(sf::Vector2f(60, 670));

        main_win->draw(score);

        score.setString("* Arrows - to turn");
        score.setCharacterSize(14);
        score.setPosition(sf::Vector2f(60, 690));

        main_win->draw(score);

        main_win->draw(score);

        main_win->display();
    }
}
