#include "game.hpp"
#include "BorderGame.hpp"
#include <SFML/Graphics.hpp>
int main()
{
    sf::RenderWindow window(sf::VideoMode(900, 500), "SFML window");

    sf::Texture texture;
    if (!texture.loadFromFile("res/snake.png"))
        return EXIT_FAILURE;
    sf::Sprite sprite(texture);

    sf::Font font;
    if (!font.loadFromFile("res/DejaVuSansMono.ttf"))
        return EXIT_FAILURE;

    
    while (window.isOpen())
    {
        // Process events
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Close window: exit
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Up){
                   Game snake;
                   snake.Run();
                }
                else if (event.key.code == sf::Keyboard::Down){
                   BorderGame Bsnake;
                   Bsnake.BorderRun();
                }
                
            }
        }
        window.clear();

        window.draw(sprite);

        window.display();
    }
    return EXIT_SUCCESS;
}