

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "snake.hpp"

class Game {
public:
    Game();
    ~Game();

    void Run();

private:
    sf::RenderWindow *main_win;

    sf::Texture earth;

    sf::Texture background;

    //sf::Texture boxex;

    sf::Event mw_event;

    sf::Font dejavu;

    sf::Clock frame_ptr;
    
    Snake mw_game;

    float speed;
};


