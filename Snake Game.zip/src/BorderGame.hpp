#include <SFML/Graphics.hpp>

#include "BorderSnake.hpp"

class BorderGame {
public:
    BorderGame();
    ~BorderGame();

    void BorderRun();

private:
    sf::RenderWindow *main_win;
    sf::Texture lifei;
    sf::Texture earth;

    sf::Texture lifej;

    sf::Texture V_boxes;
    sf::Texture H_boxes;
    sf::Texture life;
    sf::Texture background;
    
    sf::Texture box_back_r;
    sf::Texture box_back_l;
    sf::Texture box_back_u;
    sf::Texture box_back_d;

    sf::Texture lifem;
    sf::Texture lifen;

    sf::Event mw_event;

    sf::Texture lifek;

    sf::Font dejavu;

    sf::Texture lifel;

    sf::Clock frame_ptr;
    
    BorderSnake mw_game;

    float speed;
};
